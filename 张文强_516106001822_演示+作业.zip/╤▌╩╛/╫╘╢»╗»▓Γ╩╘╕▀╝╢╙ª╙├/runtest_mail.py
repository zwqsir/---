from HTMLTestRunner import HTMLTestRunner
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.header import Header
import smtplib
import unittest
import time
import os


#=====================定义发送邮件====================
def send_mail (file_new):
    f = open(file_new, 'rb')
    mail_body = f.read()
    f.close()

    smtpserver = 'smtp.163.com'
    user = 'zhangwenqiang2008@163.com'
    password = '******'
    sender = 'zhangwenqiang2008@163.com'
    receiver = '1106368586@qq.com'
    subject = '自动化测试报告'

    msg = MIMEText(mail_body, 'html', 'utf-8')
    msg['Subject'] = Header(subject, 'utf-8')
    msg['From'] = sender
    msg['To'] = receiver

    smtp = smtplib.SMTP()
    smtp.connect(smtpserver)
    smtp.login(user, password)
    smtp.sendmail(sender, receiver, msg.as_string())
    smtp.quit()
    print ('email has send out !')


#=====查找测试报告目录，找到最新生产的测试报告文件========
def new_report(testreport):
    lists = os.listdir(testreport)
    lists.sort(key=lambda fn: os.path.getmtime(testreport + "\\" + fn))
    file_new = os.path.join(testreport, lists[-1])
    print ('文件相对路径：' + file_new)
    return file_new


if __name__ == '__main__':
    
    test_dir = 'test_case'
    test_report = 'report'

    discover = unittest.defaultTestLoader.discover(test_dir, pattern='test*.py')

    now = time.strftime("%Y-%m-%d %H-%M-%S")
    filename = test_report + '/sum-' + now + '-result.html'
    fp = open(filename, 'wb')
    runner = HTMLTestRunner(stream=fp,              
                        title='测试报告',               
                        description='用例执行状况：') 
    runner.run(discover)   
    fp.close()

    new_report = new_report(test_report)
    send_mail(new_report)   # 发送测试报告
