import unittest, time
from HTMLTestRunner import HTMLTestRunner

test_dir = './test_case'
discover = unittest.defaultTestLoader.discover(test_dir, pattern='test*.py')


if __name__ == '__main__':
    
    now = time.strftime("%Y-%m-%d %H-%M-%S")
    filename = './report/sum-' + now + '-result.html'
    fp = open(filename, 'wb')

    # 定义测试报告
    runner = HTMLTestRunner(stream=fp,                  # 指定测试报告文件
                        title='测试报告',               # 定义测试报告标题 
                        description='用例执行状况：')    # 定义测试报告副标题
    runner.run(discover)    # 运行测试用例
    fp.close()  # 关闭报告文件
