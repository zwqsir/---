from selenium import webdriver
import unittest, time
from HTMLTestRunner import HTMLTestRunner
import os.path

class zwq_kmp(unittest.TestCase):
    """文件匹配"""
    def setUp(self):
        print ('start--------')

    def test_kmp_file(self):
        """开始匹配"""
        root_path = os.path.dirname(__file__)
        first_file_name = os.path.join(root_path, 'result_case1.txt')
        graph1 = []
        with open(first_file_name, 'r') as file:
            for f in file:
                graph1.append(f.strip())

        second_file_name = os.path.join(root_path, 'answer1.txt')
        graph2 = []
        with open(second_file_name, 'r') as file:
            for f in file:
                graph2.append(f.strip())
        
        for x in range(0,len(graph1)):
            self.assertEqual(graph1[x], graph2[x])

    def tearDown(self):
        print ('end--------')

if __name__ == "__main__":
    
    testunit = unittest.TestSuite()
    testunit.addTest(zwq_kmp("test_kmp_file"))

    # 按照一定格式获取当前时间
    now = time.strftime("%Y-%m-%d %H-%M-%S")

    # 定义报告存放路径
    # filename = './report/result.html'
    filename = './report/张文强-' + now + '-测试报告.html'
    fp = open(filename, 'wb')

    # 定义测试报告
    runner = HTMLTestRunner(stream=fp,                  # 指定测试报告文件
                        title='张文强索测试报告',        # 定义测试报告标题 
                        description='用例执行状况：')    # 定义测试报告副标题
    runner.run(testunit)    # 运行测试用例
    fp.close()  # 关闭报告文件